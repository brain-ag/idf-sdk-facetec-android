import { NativeModules, Platform } from 'react-native';

const LINKING_ERROR =
  `The package 'SerasaIdfCaptureLiveness3d' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo managed workflow\n';


const SerasaIdfCaptureLiveness3d = NativeModules.SerasaIdfCaptureLiveness3d
  ? NativeModules.SerasaIdfCaptureLiveness3d
  : new Proxy(
    {},
    {
      get() {
        throw new Error(LINKING_ERROR);
      },
    }
  );



export type Liveness3dConfig = {
  chave: string,
  wizard: boolean,
  segurancaExtraRootCheck: boolean,
  segurancaExtraEmulatorCheck: boolean,
  segurancaExtraSslPinning: boolean,
  tentativasDeCaptura: number,
  telaConfirmacaoDeSaida: boolean,
  retornarErros: boolean,
  utilizarCameraTraseira: boolean,
  telaSucesso: boolean,
  processType: string,
  externalDatabaseRefID: string
}

export type Liveness3d = {
  selfie: string,
  sessionId: string,
  faceScan: string
}


export type ErroLiveness3d = {
  codigo: number,
  descricao: string,
  sessionId: string
}

export type CallbackProcessamentoFacetecResult = {
  sessionId: string,
  status: string,
  wasProcessed: string,
  captureHour: string,
  errorId?: number,
  errorMsg?: string
}

export const callbackProcessingFacetec = (callbackListener: (resultado: CallbackProcessamentoFacetecResult) => void) => {

  const result = (resultado: CallbackProcessamentoFacetecResult) => {
    callbackListener(resultado)
    callbackProcessingFacetec(callbackListener)
  }

  SerasaIdfCaptureLiveness3d.callbackProcessingFacetec(result)
}

export const startLiveness3d = (config: Liveness3dConfig, sucesso: (resultado: Liveness3d) => void, falha: (resultado: ErroLiveness3d) => void) => {
  const { chave, wizard, segurancaExtraRootCheck, segurancaExtraEmulatorCheck, segurancaExtraSslPinning, tentativasDeCaptura, telaConfirmacaoDeSaida, retornarErros, utilizarCameraTraseira, telaSucesso, processType, externalDatabaseRefID  } = config;
  SerasaIdfCaptureLiveness3d.captureLiveness3d(chave, wizard, segurancaExtraRootCheck, segurancaExtraEmulatorCheck, segurancaExtraSslPinning, tentativasDeCaptura, 
    telaConfirmacaoDeSaida, retornarErros, utilizarCameraTraseira, telaSucesso, processType, externalDatabaseRefID, sucesso, falha)
}
