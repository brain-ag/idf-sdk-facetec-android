#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
#import <serasa_idf_liveness3d_ios/serasa_idf_liveness3d_ios.h>
#import <React/RCTLog.h>
#import "AppDelegate.h"

#import <React/RCTModalHostView.h>
#import <React/RCTModalHostViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface SerasaIdfCaptureLiveness3d : NSObject <RCTBridgeModule, CapturaSViewControllerDelegate>

@end

NS_ASSUME_NONNULL_END
