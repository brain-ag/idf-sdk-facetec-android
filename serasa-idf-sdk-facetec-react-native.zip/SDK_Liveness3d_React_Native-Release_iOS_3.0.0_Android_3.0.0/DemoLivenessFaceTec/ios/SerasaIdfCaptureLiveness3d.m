#import "SerasaIdfCaptureLiveness3d.h"
#include <math.h>

@implementation SerasaIdfCaptureLiveness3d

RCTResponseSenderBlock success3D;
RCTResponseSenderBlock error3D;
RCTResponseSenderBlock callback3D;

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(callbackProcessingFacetec:(RCTResponseSenderBlock)facetecCallback) {
  @try {
    callback3D = facetecCallback;
    
  } @catch (NSError *exception) {
    facetecCallback(@[exception]);
  }
}

RCT_EXPORT_METHOD(
                  captureLiveness3d:(NSString *)chave
                  wizard:(BOOL *)wizard
                  segurancaExtraRootCheck:(BOOL *)segurancaExtraRootCheck
                  segurancaExtraEmulatorCheck:(BOOL *)segurancaExtraEmulatorCheck
                  segurancaExtraSslPinning:(BOOL *)segurancaExtraSslPinning
                  tentativasDeCaptura:(double)tentativasDeCaptura
                  telaConfirmacaoDeSaida:(BOOL *)telaConfirmacaoDeSaida                  
                  retornarErros:(BOOL *)retornarErros
                  utilizarCameraTraseira:(BOOL *)utilizarCameraTraseira
                  telaSucesso:(BOOL *)telaSucesso
                  processType:(NSString *)processType
                  externalDatabaseRefID:(NSString *)externalDatabaseRefID
                  successCallback: (RCTResponseSenderBlock)successCallback
                  errorCallback: (RCTResponseSenderBlock)errorCallback)
{
  
  @try {
    
    success3D = successCallback;
    error3D = errorCallback;
    
    dispatch_async(dispatch_get_main_queue(), ^{
      
      CapturaSViewController *controller = [[CapturaSViewController alloc] initWithChave:chave wizard:wizard segurancaExtraRootCheck:segurancaExtraRootCheck segurancaExtraEmulatorCheck:segurancaExtraEmulatorCheck tentativasDeCaptura:tentativasDeCaptura telaConfirmacaoDeSaida:telaConfirmacaoDeSaida utilizarCameraTraseira:utilizarCameraTraseira retornarErros:retornarErros telaSucesso:telaSucesso processType:processType externalDatabaseRefID:externalDatabaseRefID segurancaExtraSslPinning:segurancaExtraSslPinning];
      
      controller.delegate = self;
      
      UINavigationController* appNavigator = [[UINavigationController alloc] initWithRootViewController:controller];
      [appNavigator setModalPresentationStyle:UIModalPresentationFullScreen];
      appNavigator.navigationBarHidden = true;
      AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
      [delegate.window.rootViewController presentViewController:appNavigator animated:NO completion:nil];
      
    });
  } @catch (NSError *exception) {
    errorCallback(@[exception]);
  }
}

- (void)closeCapture {
  AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
  [delegate.window.rootViewController dismissViewControllerAnimated:NO completion:nil];
}

// Selfie Delegate

- (void)erroDelegate:(NSDictionary<NSString *,id> * _Nonnull)erro {
  NSDictionary *dicErroSelfie = @{
    @"codigo": [erro objectForKey:@"codigo"],
    @"descricao": [erro objectForKey:@"descricao"],
    @"sessionId": [erro objectForKey:@"sessionId"],
  };

  error3D(@[dicErroSelfie]);
  [self closeCapture];
}

- (void)sucessoDelegate:(NSDictionary<NSString *,id> * _Nonnull)selfie {
  NSData *faceScanData = [NSKeyedArchiver archivedDataWithRootObject:[selfie objectForKey:@"faceScan"] requiringSecureCoding:NO error:nil];
  NSString *faceScan = [faceScanData base64EncodedStringWithOptions:0];
  
  NSDictionary *dicSelfie = @{
    @"selfie": [selfie objectForKey:@"selfie"],
    @"sessionId": [selfie objectForKey:@"sessionId"],
    @"faceScan": faceScan,
  };
  success3D(@[dicSelfie]);
  [self closeCapture];
}

- (void)callbackProcessamentoFacetec:(NSDictionary<NSString *,id> * _Nonnull)notificationFacetec {
  NSDictionary *dicCallback;
  if ([notificationFacetec objectForKey:@"errorId"]) {
    dicCallback = @{
      @"status": [notificationFacetec objectForKey:@"status"],
      @"wasProcessed": [notificationFacetec objectForKey:@"wasProcessed"],
      @"sessionId": [notificationFacetec objectForKey:@"sessionId"],
      @"captureHour": [notificationFacetec objectForKey:@"captureHour"],
      @"errorId": [notificationFacetec objectForKey:@"errorId"],
      @"errorMsg": [notificationFacetec objectForKey:@"errorMsg"]
    };
  } else {
    dicCallback = @{
      @"status": [notificationFacetec objectForKey:@"status"],
      @"wasProcessed": [notificationFacetec objectForKey:@"wasProcessed"],
      @"sessionId": [notificationFacetec objectForKey:@"sessionId"],
      @"captureHour": [notificationFacetec objectForKey:@"captureHour"],
    };
  }
  callback3D(@[dicCallback]);
}

@end
