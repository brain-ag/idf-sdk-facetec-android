package br.com.serasa.demo.facetec;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Arrays;

import serasa.idf.liveness3d.android.activities.SelfieActivity;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.OnSharedPreferenceChangeListener sharedPreferenceChangeListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnActionCapture = findViewById(R.id.btn_action_capture);
        btnActionCapture.setOnClickListener(view -> startCapture());

        sharedPreferences = getSharedPreferences("BRSCAN_SELFIE_PERSISTENCE", Context.MODE_PRIVATE);
        sharedPreferenceChangeListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                if (sharedPreferences != null) {
                    if (key != null && key.equals("facetecTrackerData")) {
                        String facetecTrackerData = sharedPreferences.getString(key, null);
                        Log.d("facetecTrackerData", facetecTrackerData);
                    }
                }
            }
        };

        sharedPreferences.registerOnSharedPreferenceChangeListener(sharedPreferenceChangeListener);
    }

    private void startCapture() {
        Intent intent = new Intent(this, SelfieActivity.class);

        intent.putExtra("chave", "");// INSERT KEY HERE
        intent.putExtra("wizard", true);
        intent.putExtra("segurancaExtraRootCheck", false);// TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
        intent.putExtra("segurancaExtraEmulatorCheck", false);// TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
        intent.putExtra("segurancaExtraSslPinning", false);// TO CHECK IF CERTIFICATE IS VALID (BY DEFAULT IS FALSE)
        intent.putExtra("tentativasDeCaptura", 0);
        intent.putExtra("telaConfirmacaoDeSaida", true);
        intent.putExtra("utilizarCameraTraseira", false);
        intent.putExtra("retornarErros", false);
        intent.putExtra("telaSucesso", true);
        intent.putExtra("habilitarStatusBar", false);


        SelfieActivity.selfieSuccessListener = (selfie) -> {
            Log.d("selfieSuccessListener", "onActivityResult:(Teste): arquivos: selfie " + selfie);
            Log.d("selfieSuccessListener", "onActivityResult:(Sucesso): arquivos: " + selfie.getSelfie());
            Log.d("selfieSuccessListener", "onActivityResult:(Sucesso): id: " + selfie.getFaceScan());
            Log.d("selfieSuccessListener", "onActivityResult:(Sucesso): faceScan: " + Arrays.toString(selfie.getFaceScan()));

            String facetecTrackerData = sharedPreferences.getString("facetecTrackerData", null);

            Log.d("facetecTrackerDataArray", "FacetecTrackerDataArray " + facetecTrackerData);

            sharedPreferences.edit().putString("facetecTrackerData", new JSONArray().toString()).apply();

            sharedPreferences.unregisterOnSharedPreferenceChangeListener(sharedPreferenceChangeListener);
        };

        SelfieActivity.selfieErrorListener = (error) -> {
            Log.d("selfieErrorListener", "onActivityResult:(Teste):  " + error);
            Log.d("selfieErrorListener", "onActivityResult:(Error): descricao " + error.getDescricao());

            String facetecTrackerData = sharedPreferences.getString("facetecTrackerData", null);

            Log.d("facetecTrackerDataArray", "FacetecTrackerDataArray " + facetecTrackerData);

            sharedPreferences.edit().putString("facetecTrackerData", new JSONArray().toString()).apply();

            sharedPreferences.unregisterOnSharedPreferenceChangeListener(sharedPreferenceChangeListener);
        };

        SelfieActivity.callbackProcessamentoFacetec = facetec -> {
            try {
                String status = facetec.getString("status");
                boolean wasProcessed = facetec.getBoolean("wasProcessed");
                String sessionId = facetec.getString("sessionId");
                String captureHour = facetec.getString("captureHour");

                Log.d("selfieFacetecListener", "status: " + status);
                Log.d("selfieFacetecListener", "wasProcessed: " + wasProcessed);
                Log.d("selfieFacetecListener", "sessionId: " + sessionId);
                Log.d("selfieFacetecListener", "captureHour: " + captureHour);

                String facetecTrackerData = sharedPreferences.getString("facetecTrackerData", null);

                Log.d("facetecTrackerDataArray", "FacetecTrackerDataArray " + facetecTrackerData);

                sharedPreferences.edit().putString("facetecTrackerData", new JSONArray().toString()).apply();

                sharedPreferences.unregisterOnSharedPreferenceChangeListener(sharedPreferenceChangeListener);

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        };

        startActivityForResult(intent, SelfieActivity.ACTIVITY_RESULT_CODE);
    }
}