## [3.0.6] - 02-04-2024
 Melhoria: Inclusão de biblioteca liveness3d 3.0.6.

## [3.0.0] - 29-04-2023
- Melhoria: Adicionado flag (segurancaExtraSslPinning) para habilitar verificação sslpinning.
- Melhoria: Adicionado flag (externalDatabaseRefID) id de referência enrollment/match3d-3d.
- Melhoria: Adicionado flag (processType) para selecionar o tipo de processo ("liveness", "enrollment" ou "match").
- Melhoria: Atualização de layout para nova experiência.
- Melhoria: Permitir customização dos parâmetros de textos e cores.
- Melhoria: Atualização da sdk FaceTec(9.6.85) - IOS.
- Melhoria: Inclução do arquivo PrivacyInfo.xcprivacy - IOS.

## [2.6.6] - 02-04-2024
 Melhoria: Inclusão de biblioteca liveness3d 2.6.6.
 
## [2.6.5] - 20-03-2024
 Melhoria: Inclusão de biblioteca liveness3d 2.6.5.

## [2.6.4] - 06-03-2024
 Melhoria: Inclusão de biblioteca liveness3d 2.6.4.

## [2.6.3] - 21-02-2024
 Melhoria: Inclusão de biblioteca liveness3d 2.6.3.

## [2.6.0] - 14-12-2023
 Melhoria: Inclusão de biblioteca liveness3d 2.6.0.

## [2.5.0] - 30-10-2023
- Melhoria: Inclusão de biblioteca liveness3d 2.5.0.

## [2.2.0] - 30-05-2023
- Melhoria: Inclusão de biblioteca liveness3d 2.2.0.

## [2.0.0] - 18-04-2023
- Melhoria: Inclusão do módulo liveness3d.
- Melhoria: Inclusão de biblioteca liveness3d 2.1.0.
