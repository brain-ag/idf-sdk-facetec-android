package com.example.demo_liveness_facetec

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.OnSharedPreferenceChangeListener
import android.util.Log
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.FlutterPlugin.FlutterPluginBinding
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.PluginRegistry.ActivityResultListener
import org.json.JSONArray
import serasa.idf.liveness3d.android.activities.SelfieActivity
import serasa.idf.liveness3d.android.handles.CallbackProcessamentoFacetec
import serasa.idf.liveness3d.android.handles.SelfieErrorListener
import serasa.idf.liveness3d.android.handles.SelfieSuccessListener
import serasa.idf.liveness3d.android.models.Erro
import serasa.idf.liveness3d.android.models.Selfie


class SerasaIdfCaptureLiveness3d : FlutterPlugin, MethodCallHandler, ActivityAware,
    ActivityResultListener {

    private var channel: MethodChannel? = null
    private var result: MethodChannel.Result? = null
    private var callbackProcessamentoFacetecResult: MethodChannel.Result? = null
    private var activity: Activity? = null
    private var activityBinding: ActivityPluginBinding? = null
    private var context: Context? = null

    private var selfie: Selfie? = null
    private var error: Erro? = null

    private var sharedPreferences: SharedPreferences? = null
    private var sharedPreferencesListener: OnSharedPreferenceChangeListener? = null

    @Synchronized
    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {

        when (call.method) {
            CALL_METHOD -> {
                this.result = result
                this.selfie = null
                this.error = null
                start(call)
            }
            CALLBACK_PROCESSAMENTO_FACETEC -> {
                this.callbackProcessamentoFacetecResult = result
            }
            else -> {
                result.notImplemented()
                this.result = null
            }
        }
    }

    @Synchronized
    private fun start(call: MethodCall) {
        val argumentsMap = call.arguments as HashMap<*, *>

        val key = argumentsMap[FIELD_PARAM_KEY] as String?
        val wizard = argumentsMap[FIELD_PARAM_WIZARD] as Boolean?
        val segurancaExtraRootCheck = argumentsMap[FIELD_PARAM_EXTRA_ROOT_CHECK_SECURITY] as Boolean?
        val segurancaExtraEmulatorCheck = argumentsMap[FIELD_PARAM_EXTRA_EMULATOR_CHECK_SECURITY] as Boolean?
        val tentativasDeCaptura = argumentsMap[FIELD_PARAM_CAPTURE_ATTEMPTS] as Int?
        val telaConfirmacaoDeSaida = argumentsMap[FIELD_PARAM_SCREEN_CONFIRMATION_DEPARTURE] as Boolean?
        val retornarErros = argumentsMap[FIELD_PARAM_SCREEN_RETURN_ERRORS] as Boolean?        
        val utilizarCameraTraseira = argumentsMap[FIELD_PARAM_USE_BACK_CAMERA] as Boolean?


        sharedPreferences = context?.getSharedPreferences("BRSCAN_SELFIE_PERSISTENCE", Context.MODE_PRIVATE)
        sharedPreferencesListener = OnSharedPreferenceChangeListener { sharedPreferences: SharedPreferences?, key: String? ->
            if (sharedPreferences != null) {
                if (key != null && key == "facetecTrackerData") {
                    val facetecTrackerData = sharedPreferences.getString(key, "")
                    facetecTrackerData.let {
                        Log.d("facetecTrackerData", it!!)
                    }
                }
            }
        }

        sharedPreferences?.registerOnSharedPreferenceChangeListener(sharedPreferencesListener)

        val intent = Intent(context, SelfieActivity::class.java)
        intent.putExtra(FIELD_PARAM_KEY, key)
        intent.putExtra(FIELD_PARAM_WIZARD, wizard)
        intent.putExtra(FIELD_PARAM_EXTRA_ROOT_CHECK_SECURITY, segurancaExtraRootCheck)
        intent.putExtra(FIELD_PARAM_EXTRA_EMULATOR_CHECK_SECURITY, segurancaExtraEmulatorCheck)
        intent.putExtra(FIELD_PARAM_CAPTURE_ATTEMPTS, tentativasDeCaptura)
        intent.putExtra(FIELD_PARAM_SCREEN_CONFIRMATION_DEPARTURE, telaConfirmacaoDeSaida)
        intent.putExtra(FIELD_PARAM_SCREEN_RETURN_ERRORS, retornarErros)
        intent.putExtra(FIELD_PARAM_USE_BACK_CAMERA, utilizarCameraTraseira)

        Log.d("retornarErros", retornarErros.toString())

        SelfieActivity.selfieSuccessListener = SelfieSuccessListener {
            selfie: Selfie? ->
            this.selfie = selfie
            sharedPreferences?.edit()?.putString("facetecTrackerData", JSONArray().toString())?.apply()
            sharedPreferences?.unregisterOnSharedPreferenceChangeListener(sharedPreferencesListener)
        }


        SelfieActivity.selfieErrorListener = SelfieErrorListener {
            error: Erro ->
            this.error = error
            sharedPreferences?.edit()?.putString("facetecTrackerData", JSONArray().toString())?.apply()
            sharedPreferences?.unregisterOnSharedPreferenceChangeListener(sharedPreferencesListener)
        }

        SelfieActivity.callbackProcessamentoFacetec = CallbackProcessamentoFacetec { facetec ->
            facetec.apply {
                val parameter: MutableMap<String, Any> = HashMap()
                parameter[FIELD_NAME_RESULT_SESSION_ID] = this.getString(FIELD_NAME_RESULT_SESSION_ID)
                parameter[FIELD_NAME_RESULT_STATUS] = this.getString(FIELD_NAME_RESULT_STATUS)
                parameter[FIELD_NAME_RESULT_WAS_PROCESSED] = this.getString(FIELD_NAME_RESULT_WAS_PROCESSED)
                parameter[FIELD_NAME_RESULT_CAPTURE_HOUR] = this.getString(FIELD_NAME_RESULT_CAPTURE_HOUR)

                if (this.getString(FIELD_NAME_RESULT_STATUS).equals(FIELD_NAME_RESULT_STATUS_FAILURE)) {
                    parameter[FIELD_NAME_RESULT_ERROR_ID] = this.getInt(FIELD_NAME_RESULT_ERROR_ID)
                    parameter[FIELD_NAME_RESULT_ERROR_MSG] = this.getString(FIELD_NAME_RESULT_ERROR_MSG)
                }

                callbackProcessamentoFacetecResult?.success(parameter)
            }

            sharedPreferences?.edit()?.putString("facetecTrackerData", JSONArray().toString())?.apply()
            sharedPreferences?.unregisterOnSharedPreferenceChangeListener(sharedPreferencesListener)
        }

        activity?.startActivityForResult(intent, REQUEST_CODE)
    }

    @Synchronized
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode == REQUEST_CODE) {

                this.selfie?.apply {
                    val parameter: MutableMap<String, Any> = HashMap()
                    parameter[FIELD_NAME_RESULT_SESSION_ID] = this.sessionId
                    parameter[FIELD_NAME_RESULT_SELFIE] = this.selfie
                    parameter[FIELD_NAME_RESULT_FACE_SCAN] = this.faceScan

                    result?.success(parameter)

                }

                this.error?.apply {
                    val parameter: MutableMap<String, Any> = HashMap()
                    parameter[FIELD_NAME_RESULT_SESSION_ID] = this.sessionId
                    parameter[FIELD_NAME_RESULT_ERROR_CODE] = this.codigo
                    parameter[FIELD_NAME_RESULT_ERROR_DESCRIPTION] = this.descricao
                    result?.success(parameter)
                }
            } else {
                val parameter: MutableMap<String, Any> = HashMap()
                parameter[FIELD_NAME_RESULT_SESSION_ID] = ""
                parameter[FIELD_NAME_RESULT_ERROR_CODE] = "-1"
                parameter[FIELD_NAME_RESULT_ERROR_DESCRIPTION] = "Anything is wrong"
                result?.error("-1", "Anything is wrong", parameter)
            }
        return false
    }

    @Synchronized
    override fun onAttachedToEngine(flutterPluginBinding: FlutterPluginBinding) {
        context = flutterPluginBinding.applicationContext
        channel = MethodChannel(flutterPluginBinding.binaryMessenger, CHANNEL_NAME)
        channel?.setMethodCallHandler(this)
    }

    @Synchronized
    override fun onDetachedFromEngine(binding: FlutterPluginBinding) {
        channel?.setMethodCallHandler(null)
        context = null
    }

    @Synchronized
    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
        activityBinding = binding
        activityBinding?.addActivityResultListener(this)
    }

    @Synchronized
    override fun onDetachedFromActivityForConfigChanges() {
    }

    @Synchronized
    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    @Synchronized
    override fun onDetachedFromActivity() {
        activity = null
        activityBinding?.removeActivityResultListener(this)
        activityBinding = null
        sharedPreferences = null
        sharedPreferencesListener = null
    }

    companion object {
        private const val REQUEST_CODE = 1001
        private const val CHANNEL_NAME = "serasa.idf/facetec"
        private const val CALL_METHOD = "startCapture"
        private const val CALLBACK_PROCESSAMENTO_FACETEC = "callbackProcessamentoFacetec"

        private const val FIELD_PARAM_KEY = "chave"
        private const val FIELD_PARAM_WIZARD = "wizard"
        private const val FIELD_PARAM_EXTRA_ROOT_CHECK_SECURITY = "segurancaExtraRootCheck"
        private const val FIELD_PARAM_EXTRA_EMULATOR_CHECK_SECURITY = "segurancaExtraEmulatorCheck"
        private const val FIELD_PARAM_CAPTURE_ATTEMPTS = "tentativasDeCaptura"
        private const val FIELD_PARAM_SCREEN_CONFIRMATION_DEPARTURE = "telaConfirmacaoDeSaida"
        private const val FIELD_PARAM_SCREEN_RETURN_ERRORS = "retornarErros"
        private const val FIELD_PARAM_USE_BACK_CAMERA = "utilizarCameraTraseira"

        private const val FIELD_NAME_RESULT_SESSION_ID = "sessionId"
        private const val FIELD_NAME_RESULT_SELFIE = "selfie"
        private const val FIELD_NAME_RESULT_FACE_SCAN = "faceScan"
        private const val FIELD_NAME_RESULT_ERROR_CODE = "codigo"
        private const val FIELD_NAME_RESULT_ERROR_DESCRIPTION = "descricao"

        private const val FIELD_NAME_RESULT_STATUS = "status"
        private const val FIELD_NAME_RESULT_STATUS_SUCCESS = "sucesso"
        private const val FIELD_NAME_RESULT_STATUS_FAILURE = "falha"
        private const val FIELD_NAME_RESULT_WAS_PROCESSED = "wasProcessed"
        private const val FIELD_NAME_RESULT_CAPTURE_HOUR = "captureHour"
        private const val FIELD_NAME_RESULT_ERROR_ID = "errorId"
        private const val FIELD_NAME_RESULT_ERROR_MSG = "errorMsg"
    }
}