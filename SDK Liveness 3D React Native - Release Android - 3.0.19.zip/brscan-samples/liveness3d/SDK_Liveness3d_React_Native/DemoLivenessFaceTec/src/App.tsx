import * as React from 'react';

import { StyleSheet, View, TouchableOpacity, Text } from 'react-native';
import { ErroLiveness3d, Liveness3d, Liveness3dConfig, startLiveness3d, callbackProcessingFacetec, CallbackProcessamentoFacetecResult } from './native_module_liveness_3d';

export default function App() {

    const [resultSuccessLiveness3d, setResultSuccessLiveness3d] = React.useState<Liveness3d | null>(null);
    const [resultErrorLiveness3d, setResultErrorLiveness3d] = React.useState<ErroLiveness3d | null>(null);
    
    // Liveness 3D

    const liveness3dConfig: Liveness3dConfig = {
        chave: '', // INSERT KEY HERE
        wizard: true,
        segurancaExtraRootCheck: false,// TO CHECK IF DEVICE IS RUNNING IN ROOT MODE (BY DEFAULT IS FALSE)
        segurancaExtraEmulatorCheck: false,// TO CHECK IF DEVICE IS A EMULATOR (BY DEFAULT IS FALSE)
        segurancaExtraSslPinning: false,// TO CHECK IF CERTIFICATE IS VALID (BY DEFAULT IS FALSE)
        tentativasDeCaptura: 0,
        telaConfirmacaoDeSaida: false,
        retornarErros: false,
        utilizarCameraTraseira: false,
        telaSucesso: true,
        processType: 'liveness',
        externalDatabaseRefID: '',
    }

    const handleLiveness3dSuccess = (liveness3d: Liveness3d) => {
        const json = JSON.stringify(liveness3d, null, 2)
        console.log(liveness3d.selfie)
        setResultSuccessLiveness3d(liveness3d)
        setResultErrorLiveness3d(null)
    }

    const handleLiveness3dErro = (erroLiveness3d: ErroLiveness3d) => {
        const json = JSON.stringify(erroLiveness3d, null, 2);
        console.log(json)
        setResultErrorLiveness3d(erroLiveness3d)
        setResultSuccessLiveness3d(null)
    }

    const handleLiveness3dCallbackProcessamentoFacetec = (callbackProcessFacetec: CallbackProcessamentoFacetecResult) => {
        const json = JSON.stringify(callbackProcessFacetec, null, 2);
        console.log(json)
    }

    const handleLiveness3dStart = () => {
        callbackProcessingFacetec(handleLiveness3dCallbackProcessamentoFacetec)
        startLiveness3d(liveness3dConfig, handleLiveness3dSuccess, handleLiveness3dErro)
    }



    return (
        <View style={styles.container}>


            <TouchableOpacity onPress={handleLiveness3dStart} style={styles.button}>
                <Text style={styles.buttonTitle}>Captura de Liveness 3D</Text>
            </TouchableOpacity>


            {
                resultSuccessLiveness3d && <Text style={styles.resultText}>
                    sessionId:  {resultSuccessLiveness3d.sessionId + "\n\n"}
                    selfie:  {resultSuccessLiveness3d.selfie.substring(0, 200) + "...\n\n"}
                    faceScan:  {resultSuccessLiveness3d.faceScan.substring(0, 200) + "...\n\n"}
                </Text>

            }


            {
                resultErrorLiveness3d && <Text style={styles.resultText}>
                    sessionId:  {resultErrorLiveness3d.sessionId + "\n\n"}
                    codigo:  {resultErrorLiveness3d.codigo + "\n\n"}
                    descricao:  {resultErrorLiveness3d.descricao + "\n\n"}
                </Text>

            }



        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-evenly',
        backgroundColor: "#f5f5f5"
    },
    box: {
        width: 60,
        height: 60,
        marginVertical: 20,
    },
    button: {
        width: "80%",
        height: 56,
        backgroundColor: "#002DD1",
        borderRadius: 56,
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonTitle: {
        color: "#f5f5f5",
        fontSize: 16
    },
    resultText: {
        color: "#333",
        fontSize: 16,
        padding: 16
    }
});
