package br.com.serasa.demo.facetec;

import android.app.Activity;
import android.content.Intent;
import android.util.Base64;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;

import org.json.JSONException;

import java.io.Serializable;

import serasa.idf.liveness3d.android.activities.SelfieActivity;
import serasa.idf.liveness3d.android.models.Erro;
import serasa.idf.liveness3d.android.models.Selfie;


public class SerasaIdfCaptureLiveness3d extends ReactContextBaseJavaModule implements ActivityEventListener {


    private Liveness3dConfiguracao liveness3dConfiguracao;

    private Callback sucessoCallback;
    private Callback erroCallback;
    private Callback callbackProcessamentoFacetec;
    private Selfie selfie;
    private Erro erro;

    public SerasaIdfCaptureLiveness3d(ReactApplicationContext context) {
        super(context);
        context.addActivityEventListener(this);
    }

    @NonNull
    @Override
    public String getName() {
        return "SerasaIdfCaptureLiveness3d";
    }


    @ReactMethod
    public void captureLiveness3d(String chave, boolean wizard, boolean segurancaExtraRootCheck, boolean segurancaExtraEmulatorCheck, boolean segurancaExtraSslPinning, int tentativasDeCaptura, boolean telaConfirmacaoDeSaida, boolean retornarErros, boolean utilizarCameraTraseira, boolean telaSucesso, String processType, String externalDatabaseRefID, boolean habilitarStatusBar, Callback sucessoCallback, Callback erroCallback) {
        this.liveness3dConfiguracao = new Liveness3dConfiguracao(chave, wizard, segurancaExtraRootCheck, segurancaExtraEmulatorCheck, segurancaExtraSslPinning, tentativasDeCaptura, telaConfirmacaoDeSaida, retornarErros, utilizarCameraTraseira, telaSucesso, processType, externalDatabaseRefID, habilitarStatusBar);
        this.sucessoCallback = sucessoCallback;
        this.erroCallback = erroCallback;
        this.selfie = null;
        this.erro = null;
        iniciaCaptura();
    }

    @ReactMethod
    public void callbackProcessingFacetec(Callback callbackListener) {
        this.callbackProcessamentoFacetec = callbackListener;
    }

    private void iniciaCaptura() {
        Intent intent = new Intent(getCurrentActivity(), SelfieActivity.class);
        intent.putExtra("chave", this.liveness3dConfiguracao.getChave());
        intent.putExtra("wizard", this.liveness3dConfiguracao.isWizard());
        intent.putExtra("segurancaExtraRootCheck", this.liveness3dConfiguracao.isSegurancaExtraRootCheck());
        intent.putExtra("segurancaExtraEmulatorCheck", this.liveness3dConfiguracao.isSegurancaExtraEmulatorCheck());
        intent.putExtra("segurancaExtraSslPinning", this.liveness3dConfiguracao.isSegurancaExtraSslPinning());
        intent.putExtra("tentativasDeCaptura", this.liveness3dConfiguracao.getTentativasDeCaptura());
        intent.putExtra("telaConfirmacaoDeSaida", this.liveness3dConfiguracao.isTelaConfirmacaoDeSaida());
        intent.putExtra("retornarErros", this.liveness3dConfiguracao.isRetornarErros());
        intent.putExtra("utilizarCameraTraseira",liveness3dConfiguracao.isUtilizarCameraTraseira());
        intent.putExtra("telaSucesso",liveness3dConfiguracao.isTelaSucesso());
        intent.putExtra("processType",liveness3dConfiguracao.getProcessType());
        intent.putExtra("externalDatabaseRefID",liveness3dConfiguracao.getExternalDatabaseRefID());
        intent.putExtra("habilitarStatusBar",liveness3dConfiguracao.isHabilitarStatusBar());


        SelfieActivity.selfieSuccessListener = selfie -> this.selfie = selfie;

        SelfieActivity.selfieErrorListener = error -> this.erro = error;
        if (getCurrentActivity() != null)
            getCurrentActivity().startActivityForResult(intent, SelfieActivity.ACTIVITY_RESULT_CODE);

        SelfieActivity.callbackProcessamentoFacetec = facetec -> {
            try {
                WritableMap facetecMap = Arguments.createMap();

                facetecMap.putString("sessionId", facetec.getString("sessionId"));
                facetecMap.putString("status", facetec.getString("status"));
                facetecMap.putString("wasProcessed", facetec.getString("wasProcessed"));
                facetecMap.putString("captureHour", facetec.getString("captureHour"));

                if (facetec.getString("status").equals("falha")) {
                    facetecMap.putInt("errorId", facetec.getInt("errorId"));
                    facetecMap.putString("errorMsg", facetec.getString("errorMsg"));
                }

                if (callbackProcessamentoFacetec != null) callbackProcessamentoFacetec.invoke(facetecMap);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        };
    }


    @Override
    public void onActivityResult(Activity activity, int requestCode, int resultCode, Intent data) {
        if (requestCode == SelfieActivity.ACTIVITY_RESULT_CODE) {
            if (selfie != null) {
                WritableMap selfieMap = Arguments.createMap();
                selfieMap.putString("sessionId", selfie.getSessionId());
                selfieMap.putString("selfie", selfie.getSelfie());

                String faceScan = Base64.encodeToString(selfie.getFaceScan(), Base64.DEFAULT);
                selfieMap.putString("faceScan", faceScan);

                if (sucessoCallback != null) sucessoCallback.invoke(selfieMap);
            } else if (erro != null) {
                WritableMap erroMap = Arguments.createMap();

                erroMap.putInt("codigo", erro.getCodigo());
                erroMap.putString("descricao", erro.getDescricao());
                erroMap.putString("sessionId", erro.getSessionId());
                if (erroCallback != null) erroCallback.invoke(erroMap);
            }
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
    }


    private class Liveness3dConfiguracao implements Serializable {

        private String chave;
        private boolean wizard;
        private boolean segurancaExtraRootCheck;
        private boolean segurancaExtraEmulatorCheck;
        private boolean segurancaExtraSslPinning;
        private int tentativasDeCaptura;
        private boolean telaConfirmacaoDeSaida;
        private boolean retornarErros;
        private boolean utilizarCameraTraseira;
        private boolean telaSucesso;
        private String processType;
        private String externalDatabaseRefID;
        private boolean habilitarStatusBar;

        public Liveness3dConfiguracao(String chave, boolean wizard, boolean segurancaExtraRootCheck, boolean segurancaExtraEmulatorCheck, boolean segurancaExtraSslPinning, int tentativasDeCaptura, boolean telaConfirmacaoDeSaida, boolean retornarErros, boolean utilizarCameraTraseira, boolean telaSucesso, String processType, String externalDatabaseRefID, boolean habilitarStatusBar) {
            this.chave = chave;
            this.wizard = wizard;
            this.segurancaExtraRootCheck = segurancaExtraRootCheck;
            this.segurancaExtraEmulatorCheck = segurancaExtraEmulatorCheck;
            this.segurancaExtraSslPinning = segurancaExtraSslPinning;
            this.tentativasDeCaptura = tentativasDeCaptura;
            this.telaConfirmacaoDeSaida = telaConfirmacaoDeSaida;
            this.retornarErros = retornarErros;
            this.utilizarCameraTraseira = utilizarCameraTraseira;
            this.telaSucesso = telaSucesso;
            this.processType = processType;
            this.externalDatabaseRefID = externalDatabaseRefID;
            this.habilitarStatusBar = habilitarStatusBar;
        }

        public String getChave() {
            return chave;
        }

        public boolean isWizard() {
            return wizard;
        }

        public boolean isSegurancaExtraRootCheck() {
            return segurancaExtraRootCheck;
        }

        public boolean isSegurancaExtraEmulatorCheck() {
            return segurancaExtraEmulatorCheck;
        }

        public boolean isSegurancaExtraSslPinning() {
            return segurancaExtraSslPinning;
        }

        public int getTentativasDeCaptura() {
            return tentativasDeCaptura;
        }

        public boolean isTelaConfirmacaoDeSaida() {
            return telaConfirmacaoDeSaida;
        }

        public boolean isRetornarErros() {
            return retornarErros;
        }

        public boolean isUtilizarCameraTraseira() {
            return utilizarCameraTraseira;
        }

        public boolean isTelaSucesso() {
            return telaSucesso;
        }

        public String getProcessType() {
            return processType;
        }

        public String getExternalDatabaseRefID() {
            return externalDatabaseRefID;
        }

        public boolean isHabilitarStatusBar() {
            return habilitarStatusBar;
        }

        public void setHabilitarStatusBar(boolean habilitarStatusBar) {
            this.habilitarStatusBar = habilitarStatusBar;
        }
    }

}
