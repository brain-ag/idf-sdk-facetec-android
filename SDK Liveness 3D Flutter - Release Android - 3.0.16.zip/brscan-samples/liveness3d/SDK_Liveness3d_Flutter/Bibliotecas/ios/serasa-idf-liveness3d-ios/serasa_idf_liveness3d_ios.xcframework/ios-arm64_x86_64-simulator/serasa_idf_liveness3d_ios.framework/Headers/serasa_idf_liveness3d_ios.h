//
//  serasa_idf_liveness3d_ios.h
//  serasa-idf-liveness3d-ios
//
//  Created by c93514a on 17/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for serasa_idf_liveness3d_ios.
FOUNDATION_EXPORT double serasa_idf_liveness3d_iosVersionNumber;

//! Project version string for serasa_idf_liveness3d_ios.
FOUNDATION_EXPORT const unsigned char serasa_idf_liveness3d_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <serasa_idf_liveness3d_ios/PublicHeader.h>


