## [3.0.2] - 06-08-2024
- Melhoria: Atualização da sdk FaceTec(9.6.103)

## [3.0.1] - 05-06-2024
- Melhoria: Atualização da sdk FaceTec(9.6.94)

## [3.0.0] - 29-04-2023
- Melhoria: Adicionado flag (segurancaExtraSslPinning) para habilitar verificação sslpinning.
- Melhoria: Adicionado flag (externalDatabaseRefID) id de referência enrollment/match3d-3d.
- Melhoria: Adicionado flag (processType) para selecionar o tipo de processo ("liveness", "enrollment" ou "match").
- Melhoria: Atualização de layout para nova experiência.
- Melhoria: Permitir customização dos parâmetros de textos e cores.
- Melhoria: Atualização da sdk FaceTec(9.6.85)
- Melhoria: Inclução do arquivo PrivacyInfo.xcprivacy

## [2.6.6] - 02-04-2024
- Melhoria: Atualização da framework FaceTec (v9.6.82)

## [2.6.5] - 19-03-2024
- Melhoria: Atualização da framework FaceTec (v9.6.80)

## [2.6.4] - 07-03-2024
- Melhoria: Atualização da framework FaceTec (v9.6.78)

## [2.6.3] - 22-02-2024
- Melhoria: Atualização da framework FaceTec (v9.6.76)

## [2.6.2] - 06-02-2024
- Melhoria: Atualização da framework FaceTec (v9.6.74)

## [2.6.0] - 30-11-2023
- Melhoria: Atualização da framework FaceTec (v9.6.62)

## [2.5.0] - 30-10-2023
- Melhoria: Inclusão de strings para customização das cores dos textos, botões e shapes da aplicação;
- Melhoria: Inclusão de novo callback para sucesso e erro
- Melhoria: Inclusão da flag "retornarErros", para permitir que o cliente, fora do SDK, faça o tratamento de erros.

## [2.1.0] - 06-04-2023
- Melhoria: Atualização da framework FaceTec (v9.6.24)

## [2.0.1] - 31-01-2023
- Correção: Corrigido o problema de importação do bundle com as imagens, textos e fontes.

## [2.0.0] - 30-01-2023
- Melhoria: atualização de layout para nova experiência com acessibilidade.
- Melhoria: ícones de telas customizáveis.

## [1.0.0] - 26-09-2022
- Melhoria: Atualização da framework FaceTec 
- Melhoria: Inclusão da flag tentativasDeCaptura (default = 0)
- Melhoria: Possibilidade de customização de cores do componente

## [0.9.0] - 02-09-2022
- Melhoria: integração com componente facatec.
- Melhoria: Adicionado flag (wizard).
- Melhoria: Adicionado flag (segurancaExtraRootCheck) para validar se o dispositivo está no modo root.
- Melhoria: Adicionado flag (segurancaExtraEmulatorCheck) para validar se o dispositivo é um emulador.
- Melhoria: Retorno de imagem em base64.


