import UIKit
import Flutter

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let resultObject = FacetecResult()
    GeneratedPluginRegistrant.register(with: self)
        
    guard let controller = window?.rootViewController as? FlutterViewController else {
      fatalError("rootViewController is not type FlutterViewController")
    }
        let navigationController = UINavigationController(rootViewController: controller)
        navigationController.isNavigationBarHidden = true
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
        
    let captureChannel = FlutterMethodChannel(name: "serasa.idf/facetec",
                                              binaryMessenger: controller.binaryMessenger)
        captureChannel.setMethodCallHandler({(call: FlutterMethodCall, result: @escaping FlutterResult) -> Void in
            if call.method == "callbackProcessamentoFacetec" {
                resultObject.resultCallbackListener = result
            }
            if call.method == "startCapture" {
                resultObject.result = result
                let arguments = call.arguments as! [String: Any]
            let capture = SelfieCaptureViewController(flutterResult: result, arguments: arguments, result: resultObject)
            controller.navigationController?.pushViewController(capture, animated: true)
            }
            
 
            
    })
        
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
  
}
