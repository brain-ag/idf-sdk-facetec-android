import 'dart:async';
import 'package:flutter/material.dart';
import 'native_mode_serasa_idf_liveness_facetec.dart' as liveness_facetec;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 0, 45, 209)),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Demo LivenessFacetec Capture'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _result = '';

  Future<void> _startCapture() async {
    var params = <String, Object>{};

    params[liveness_facetec.keyChave] = ""; // INSERT KEY HERE
    params[liveness_facetec.keyWizard] = true;
    params[liveness_facetec.keyRetornarErros] = false;
    params[liveness_facetec.keySegurancaExtraRootCheck] =
        false; // TO CHECK IF DEVICE IS RUNNING IN ROOT MODE
    params[liveness_facetec.keySegurancaExtraEmulatorCheck] =
        false; // TO CHECK IF DEVICE IS A EMULATOR
    params[liveness_facetec.keySegurancaExtraSslPinning] =
        false; // TO CHECK IF CERTIFICATE IS VALID
    params[liveness_facetec.keyTentativasDeCaptura] = 0;
    params[liveness_facetec.keyTelaConfirmacaoDeSaida] = true;
    params[liveness_facetec.keyUseBackCamera] = false;
    params[liveness_facetec.keyTelaSucesso] = true;
    params[liveness_facetec.keyProcessType] = "liveness";
    params[liveness_facetec.keyExternalDatabaseRefID] = "";
    params[liveness_facetec.keyHabilitarStatusBar] = false;

    liveness_facetec.startCapture(
        params: params,
        onCallbackListener: (callback) {
          debugPrint("--- Callback PROCESSAMENTO ---");
          debugPrint("Callback: $callback");
        },
        onSuccess: (selfie) {
          // Callback Success

          debugPrint("--- Callback Success ---");
          debugPrint(
              "sessionId: ${selfie[liveness_facetec.keyResultSessionId]}");
          debugPrint("selfie: ${selfie[liveness_facetec.keyResultSelfie]}");
          debugPrint("faceScan: ${selfie[liveness_facetec.keyResultFaceScan]}");

          setState(() {
            _result =
                'Success:\n, ${selfie[liveness_facetec.keyResultFaceScan].toString()} ${selfie.toString()} ';
          });
        },
        onError: (error) {
          // Callback Error

          debugPrint("--- Callback Error ---");
          debugPrint(
              "sessionId: ${error[liveness_facetec.keyResultSessionId]}");
          debugPrint("codigo: ${error[liveness_facetec.keyResultErrorCode]}");
          debugPrint(
              "descricao: ${error[liveness_facetec.keyResultErrorDescription]}");

          setState(() {
            _result = 'Error:\n ${error.toString()} ';
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        backgroundColor: const Color.fromARGB(255, 0, 45, 209),
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                    onPressed: _startCapture,
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: const Color.fromARGB(
                          255, 0, 45, 209), // Background color
                    ),
                    child: const Text("Start LivenessFacetec Capture")),
              ),
              Visibility(
                  visible: _result.isNotEmpty,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      _result,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                  )),
            ],
          ),
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
