import 'package:flutter/services.dart';

const channelName = "serasa.idf/facetec";
const eventStartCapture = "startCapture";
const eventFacetecCallbackListener = "callbackProcessamentoFacetec";

const keyChave = "chave";
const keyWizard = "wizard";
const keySegurancaExtraRootCheck = "segurancaExtraRootCheck";
const keySegurancaExtraEmulatorCheck = "segurancaExtraEmulatorCheck";
const keySegurancaExtraSslPinning = "segurancaExtraSslPinning";
const keyTentativasDeCaptura = "tentativasDeCaptura";
const keyTelaConfirmacaoDeSaida = "telaConfirmacaoDeSaida";
const keyRetornarErros = "retornarErros";
const keyUseBackCamera = "utilizarCameraTraseira";
const keyTelaSucesso = "telaSucesso";

const keyResultSessionId = "sessionId";
const keyResultSelfie = "selfie";
const keyResultFaceScan = "faceScan";
const keyResultErrorCode = "codigo";
const keyResultErrorDescription = "descricao";

const platform = MethodChannel(channelName);

void startCapture(
    {required Map params,
    required Function(Map selfie) onSuccess,
    required Function(Map error) onError,
    required Function(Map callbackListener) onCallbackListener}) async {
  try {
    startFacetecCallbackListener(onCallbackListener: onCallbackListener);

    Map result =
        await platform.invokeMethod<Map>(eventStartCapture, params) as Map;

    if (result.containsKey(keyResultSelfie)) {
      onSuccess(result);
    } else {
      onError(result);
    }
  } on PlatformException catch (e) {
    Map genericError = <String, Object>{};
    genericError[keyResultErrorCode] = -1;
    genericError[keyResultSessionId] = "";
    genericError[keyResultErrorDescription] = e.message;
    onError(genericError);
  }
}

void startFacetecCallbackListener(
    {required Function(Map callbackListener) onCallbackListener}) async {
  try {
    Map result =
        await platform.invokeMethod<Map>(eventFacetecCallbackListener) as Map;
    onCallbackListener(result);
  } on PlatformException catch (_) {
  } finally {
    startFacetecCallbackListener(onCallbackListener: onCallbackListener);
  }
}
