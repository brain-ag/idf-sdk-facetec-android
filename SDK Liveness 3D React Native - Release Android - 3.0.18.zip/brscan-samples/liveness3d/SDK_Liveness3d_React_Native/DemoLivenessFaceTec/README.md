# brscan-sdk-react-native-demo

Utilizando tecnologias de Reconhecimento Facial, Machine Learning, Visão Computacional e Redes Neurais de aprendizagem a BrScan desenvolve sistemas que buscam aprimorar os processos de Onboarding Digital de fluxos de cadastro e autenticação de Clientes. A utilização destas soluções permite mitigar riscos de cadastros e identificar pessoas que possam estar tentado burlar processos de captura do documento de identificação. Neste repositório é possível obter a versão de demonstração e ter  uma visão técnica do processo de prova de vida, captura de selfie e captura do documento de identificação do cliente, suas dependências e seus meios de implementação em sistemas de terceiros.

Para o correto funcionamento do componente, o utilizador precisa estar conectado à internet com permissão de acesso ao BrFlow (https://www.brflow.com.br) e Liveness ( https://liveness.brscan.com.br). As requisições são realizadas usando o protocolo HTTPS e todo o processo de captura salva as imagens no diretório da aplicação, a remoção das imagens armazenadas no dispositivo após o uso é de responsabilidade do utilizador.

Abaixo serão apresentadas as dependências necessárias para o correto funcionamento dos componentes, exemplos e orientações de como instanciar o processo dentro de uma aplicação e munir o consumidor com um fluxo que detalha todas as integrações que são realizadas durante cada processo.

# Configuração de utilização do SDK

É necessário enviar a chave durante a incialização do componente. Para incluir a chave é necessário alterar o arquivo que se encontra no arquivo: src/App.tsx

```
 
const liveness3dConfig: Liveness3dConfig = {
        chave: '',
        wizard: false,
        segurancaExtraRootCheck: true,
        segurancaExtraEmulatorCheck: false,
        tentativasDeCaptura: 0,
        telaConfirmacaoDeSaida: true
}

```

Todos os parametros que são configuráveis durante a inicialização se encontram dentro da chamada no exemplo.

# Requisítos minimos

## Sistema operacional:
* Android 5 ou superior
* Iphone 11 ou superior

## Hardware:
* Câmera de 2MP com autofoco ou superior
* CPU armv8 ou superior
* Memória RAM 512MB ou superior
* Memória Interna com 512MB livre ou superior
* Resolução da tela de 1280x720 (HD) ou superior
* Conexão com internet
