import UIKit
import Flutter
import serasa_idf_liveness3d_ios

class SelfieCaptureViewController: UIViewController {
    var flutterResult: FlutterResult
    var arguments: [String: Any]
    var result: FacetecResult
    
    init(flutterResult: @escaping FlutterResult, arguments: [String: Any], result: FacetecResult) {
        self.flutterResult = flutterResult
        self.arguments = arguments
        self.result = result
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    func start() {
        
    let chave = arguments["chave"] as? String ?? ""
    let wizard = arguments["wizard"] as? Bool ?? false
    let segurancaExtraRootCheck = arguments["segurancaExtraRootCheck"] as? Bool ?? false
    let segurancaExtraEmulatorCheck = arguments["segurancaExtraEmulatorCheck"] as? Bool ?? false
    let telaConfirmacaoDeSaida = arguments["telaConfirmacaoDeSaida"] as? Bool ?? false
    let tentativasDeCaptura = arguments["tentativasDeCaptura"] as? Int ?? 0
    let retornarErros = arguments["retornarErros"] as? Bool ?? false
    let utilizarCameraTraseira = arguments["utilizarCameraTraseira"] as? Bool ?? false
        
        let captura = CapturaSViewController(
            chave: chave,
            wizard: wizard,
            segurancaExtraRootCheck: segurancaExtraRootCheck,
            segurancaExtraEmulatorCheck: segurancaExtraEmulatorCheck,
            tentativasDeCaptura: tentativasDeCaptura,
            telaConfirmacaoDeSaida: telaConfirmacaoDeSaida,
            utilizarCameraTraseira: utilizarCameraTraseira,
            retornarErros: retornarErros
        )
        view.backgroundColor = .white
        captura.delegate = self
        addChild(captura)
        view.addSubview(captura.view)
        captura.didMove(toParent: self)
        captura.view.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        captura.view.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        captura.view.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        captura.view.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        start()
        
    }
}

extension SelfieCaptureViewController: CapturaSViewControllerDelegate {
    func callbackProcessamentoFacetec(_ notificationFacetec: [String : Any]) {
//        print("callbackProcessamentoFacetec \(notificationFacetec)")
        let response : NSMutableDictionary! = [:]
        response["status"] = notificationFacetec["status"]
        response["wasProcessed"] = notificationFacetec["wasProcessed"]
        response["captureHour"] = notificationFacetec["captureHour"]
        if  response["status"] as! String == "falha"{
            response["errorId"] = notificationFacetec["errorId"]
            response["errorMsg"] = notificationFacetec["errorMsg"]
        }
        result.resultCallbackListener!(response)
    }
    
    func sucessoDelegate(_ selfie: [String : Any]) {
        let response : NSMutableDictionary! = [:]
        response["selfie"] = selfie["selfie"]
        response["sessionId"] = selfie["sessionId"]
        response["faceScan"] = selfie["faceScan"]
        
        result.result!(response)
        navigationController?.popToRootViewController(animated: false)
    }
    
    func erroDelegate(_ erro: [String : Any]) {
        let response : NSMutableDictionary! = [:]
        response["codigo"] = erro["codigo"]
        response["descricao"] = erro["descricao"]
        response["sessionId"] = erro["sessionId"]
        result.result!(response)
                navigationController?.popToRootViewController(animated: false)
    }
}

class FacetecResult {
    var result:  FlutterResult?
    var resultCallbackListener: FlutterResult?
}

